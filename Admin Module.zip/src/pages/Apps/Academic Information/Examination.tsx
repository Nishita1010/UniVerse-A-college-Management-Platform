import React from 'react'

const Examination = () => {
  return (
    <div>Examination</div>
  )
}

export default Examination;
